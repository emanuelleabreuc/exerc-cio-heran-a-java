public abstract class Musica implements Reproduzivel {
    public String titulo;
    public String artista;

    public Musica(String titulo, String artista) {
        this.titulo = titulo;
        this.artista = artista;
    }

    public String getDescricao() {
        return titulo + " - " + artista;
    }
}
