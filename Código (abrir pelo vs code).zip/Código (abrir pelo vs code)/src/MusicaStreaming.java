public class MusicaStreaming extends Musica {

    public MusicaStreaming(String titulo, String artista) {
        super(titulo, artista);
    }

    @Override
    public void reproduzir() {
        System.out.println("Reproduzindo (streaming): " + getDescricao());
    }
}
