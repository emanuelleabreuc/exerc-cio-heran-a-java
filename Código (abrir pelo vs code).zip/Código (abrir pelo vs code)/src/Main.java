public class Main {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("Emanuelle", "emanuelle@email.com");

        Playlist sertanejoPlaylist = new Playlist("Pra chorar na coitadolandia");
        sertanejoPlaylist.adicionarMusica(new MusicaStreaming("Whisky e gelo", "Ze neto e cristiano"));
        sertanejoPlaylist.adicionarMusica(new MusicaDownload("Tubaroes", "Diego e victor hugo"));

        Playlist funkPlaylist = new Playlist("Funk pra atrair loiras");
        funkPlaylist.adicionarMusica(new MusicaDownload("10+6 MINUTINHOS NO PIQUEZIN DO MC PH", "DJ RM"));

        usuario.adicionarPlaylist(sertanejoPlaylist);
        usuario.adicionarPlaylist(funkPlaylist);

        usuario.mostrarPlaylists();

        
        MusicaDownload musica = new MusicaDownload("Favorite girl", "Justin Bieber");
        musica.baixar();
    }
}
