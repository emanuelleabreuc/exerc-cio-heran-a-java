import java.util.ArrayList;
import java.util.List;

public class Usuario {
    private String nome;
    private String email;
    private List<Playlist> playlists;

    public Usuario(String nome, String email) {
        this.nome = nome;
        this.email = email;
        this.playlists = new ArrayList<>();
    }

    public void adicionarPlaylist(Playlist p) {
        playlists.add(p);
    }

    public void mostrarPlaylists() {
        System.out.println("Playlists de " + nome + ":");
        for (Playlist p : playlists) {
            System.out.println(p.getNome());
        for (Musica m : p.getMusicas()) {
                System.out.print("  ");
                m.reproduzir();
            }
        }
    }
}
