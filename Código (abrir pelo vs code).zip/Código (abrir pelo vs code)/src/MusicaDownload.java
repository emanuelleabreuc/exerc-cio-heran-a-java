public class MusicaDownload extends Musica {

    public MusicaDownload(String titulo, String artista) {
        super(titulo, artista);
    }

    @Override
    public void reproduzir() {
        System.out.println("Reproduzindo (download): " + getDescricao());
    }

    public void baixar() {
        System.out.println("Baixando: " + getDescricao());
    }
}
