public interface Reproduzivel {
    void reproduzir();
}
